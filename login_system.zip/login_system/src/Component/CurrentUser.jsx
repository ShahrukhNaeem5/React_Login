import React from 'react';

const CurrentUser = () => {
  const user = JSON.parse(localStorage.getItem('currentUser'));

  if (!user) {
    return <p>No user is currently logged in.</p>;
  }

  return (
    <div>
      <h2>Current User</h2>
      <p><strong>Name:</strong> {user.name}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <img src={user.avatar} alt="User Avatar" />
    </div>
  );
}

export default CurrentUser;
