import React from 'react';
import { useState } from 'react';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const navigate = useNavigate(); // Hook for navigation

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    const { name, email, password } = formData;

    if (name.length > 3) {
      if (email.length > 6) {
        if (password.length > 6) {
          const newUser = {
            name: name,
            email: email,
            password: password,
            avatar: `https://ipfs.io/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/${Math.floor(Math.random() * 6 + 2)}.jpg`
          };

          try {
            const response = await fetch("https://66508778ec9b4a4a60326b3e.mockapi.io/shopify/UserRegistration", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(newUser)
            });

            if (response.ok) {
              toast.success("Registration successful!");
              setFormData({ name: '', email: '', password: '' });
              navigate('/login'); // Redirect to login page
            } else {
              throw new Error('Failed to register user');
            }
          } catch (error) {
            toast.error(error.message);
          }
        } else {
          toast.error("Password must be at least 6 characters long");
        }
      } else {
        toast.error("Invalid email address");
      }
    } else {
      toast.error("Name must be more than 3 characters");
    }
  };

  return (
    <div className='container p-2'>
      <form onSubmit={handleRegister}>
        <h2>Register</h2>
        <div className="form-group">
          <label htmlFor="exampleInputName">User Name</label>
          <input
            type="text"
            name='name'
            value={formData.name}
            onChange={handleChange}
            className="form-control"
            id="exampleInputName"
            placeholder="Enter User Name"
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Email address</label>
          <input
            type="email"
            name='email'
            value={formData.email}
            onChange={handleChange}
            className="form-control"
            id="exampleInputEmail1"
            placeholder="Enter User email"
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input
            type="password"
            name='password'
            value={formData.password}
            onChange={handleChange}
            className="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
          />
        </div>
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
    </div>
  );
}

export default Register;
