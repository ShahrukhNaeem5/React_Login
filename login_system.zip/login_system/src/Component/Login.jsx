import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const navigate=useNavigate();


  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    const { email, password } = formData;

    try {
      const response = await fetch("https://66508778ec9b4a4a60326b3e.mockapi.io/shopify/UserRegistration");
      const users = await response.json();
      const user = users.find(user => user.email === email && user.password === password);

      if (user) {
        toast.success("Login successful!");
        localStorage.setItem('currentUser', JSON.stringify(user));
        setFormData({ email: '', password: '' });
        navigate('/current-user')
      } else {
        toast.error("Invalid email or password");
      }
    } catch (error) {
      toast.error("Failed to login");
    }
  };

  return (
    <div className='container p-2'>
      <form onSubmit={handleLogin}>
        <h2>Login</h2>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Email address</label>
          <input
            type="email"
            name='email'
            value={formData.email}
            onChange={handleChange}
            className="form-control"
            id="exampleInputEmail1"
            placeholder="Enter User email"
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input
            type="password"
            name='password'
            value={formData.password}
            onChange={handleChange}
            className="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
          />
        </div>
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
    </div>
  );
}

export default Login;
